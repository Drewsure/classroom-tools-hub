# How to Reliably Provide Updated Files in the "All Files in Task" Panel

> A strong, prescriptive description of the exact mechanism that guarantees a downloadable file appears in the "All files in task" panel at the end of every update. Paste this into any AI project where file delivery is unreliable.

---

## The Core Mechanism (read this first)

The "All files in task" panel is populated by **one thing only**: a real file existing on disk in a specific directory when the AI's response completes.

It is NOT populated by:
- Chat text mentioning a file name
- Code blocks in the response
- Markdown rendered in the chat
- Files saved to `/tmp`, `~`, project root, `src/`, or any other path
- Files that were "almost created" but failed silently

The panel scans exactly one directory: **`/home/z/my-project/download/`**.

If a file exists there when the response ends, it appears in the panel.
If no file exists there, the panel is empty — regardless of what the AI says in chat.

---

## The 5-Step Delivery Protocol (mandatory for every task)

Every response that touches code or content MUST follow these 5 steps, in this order:

### Step 1 — Classify the deliverable

Before doing anything, determine what the user will receive:
- A **document** (.docx, .pdf, .xlsx, .pptx) → use the matching Skill first
- A **chart/image** (.png, .svg) → use the `charts` or `image-generation` Skill
- A **code file** the user needs to download → save as a file in `/home/z/my-project/download/`
- A **patch/update to existing code** → save the patched file (or a diff/patch file) to `/home/z/my-project/download/`
- A **pure conversational answer** → still save a `summary.md` of the answer

**An empty download panel is never acceptable.** Every response ends with at least one file.

### Step 2 — Write the file to the exact required path

Use the `Write` tool (or a persisted script that writes the file) to save the deliverable to:

```
/home/z/my-project/download/<descriptive-name>.<ext>
```

Rules:
- The path MUST start with `/home/z/my-project/download/`
- Use a descriptive, unique filename (e.g., `classroom-tools-patch-v3.diff`, `weekly-report-2026-08-17.pdf`, `theme-fix-instructions.md`)
- For multi-file deliveries, create a subdirectory: `/home/z/my-project/download/<task-name>/`
- Never overwrite a previously-delivered file from a prior task unless the user explicitly asks for a re-delivery

### Step 3 — Verify the file exists on disk

Before composing the final response, run:

```bash
ls -la /home/z/my-project/download/
```

Read the output. Confirm:
- The file is listed
- The file size is greater than 0 bytes
- The timestamp is recent (this run, not a stale file from a prior task)

If any of these fail, **do not respond "done"**. Re-run the script, fix the issue, then verify again.

### Step 4 — Call the file-delivery tool (in IM/chat mode)

If a `send_message` tool (or equivalent file-delivery tool) is available in the environment, call it with the absolute path:

```
send_message(file_path="/home/z/my-project/download/<file-name>.<ext>")
```

This is what actually pushes the file into the user's chat panel. Without this call, the file exists on disk but the user never sees it in their IM client.

If no `send_message` tool exists (plain CLI mode), skip this step — the panel scans the directory automatically.

### Step 5 — Mention the file explicitly in the response text

The final response must include:
- The exact file name
- A one-line summary of what's in it
- What the user should do next (review, paste into project, etc.)

Example closing paragraph:

> I've saved the updated `theme-fix-instructions.md` to your download folder. It contains the 3 critical patches (body background, shadcn token override, hover lift) plus the exact CSS to paste into Classroom Tools' `globals.css`. Next step: open the file, copy each code block, and apply them in order to your other project.

---

## What Does NOT Work (the actual failure modes)

These are the real reasons "All files in task" comes up empty. Audit any AI agent against this list:

### Failure 1 — File written to wrong path
- **Symptom:** AI says "I saved the file" but the panel is empty.
- **Cause:** File was saved to `/tmp`, `./output/`, project root, or `~`.
- **Fix:** Hard-code `/home/z/my-project/download/` as the output path in every script and every `Write` call.

### Failure 2 — Long script run inline
- **Symptom:** AI ran `python -c "..."` with a 50-line script, no file appeared.
- **Cause:** Inline execution swallows errors silently; the script likely crashed mid-run.
- **Fix:** Save the script to `/home/z/my-project/scripts/<name>.py` first, then execute it as a file. On failure, use `Edit` to patch the script and re-run — don't regenerate from scratch.

### Failure 3 — File written but `send_message` not called (IM mode)
- **Symptom:** File exists on disk (verified via `ls`) but user doesn't see it in chat.
- **Cause:** AI forgot to call `send_message` with the file path.
- **Fix:** Make `send_message(file_path=...)` the last tool call before the response text.

### Failure 4 — Claiming "done" without verification
- **Symptom:** AI says "file created" but `ls` would show no file.
- **Cause:** Silent write failure (permission, missing font, broken path) that AI didn't catch.
- **Fix:** `ls -la /home/z/my-project/download/` is mandatory. No exceptions.

### Failure 5 — Only chat Markdown, no file
- **Symptom:** AI wrote the full content as `# Heading` + code blocks in chat, panel empty.
- **Cause:** AI confused "answered in chat" with "delivered a file."
- **Fix:** Chat text is not a file. Always save the same content as a `.md` (or proper document format) to `/home/z/my-project/download/`.

### Failure 6 — Skill not loaded before document generation
- **Symptom:** File is created but is broken (empty pages, missing fonts, corrupted).
- **Cause:** AI wrote a `.docx` / `.pdf` / `.xlsx` from scratch without loading the matching Skill first, missing mandatory formatting rules.
- **Fix:** Always `Skill(command="docx|pdf|xlsx|pptx")` BEFORE writing any document-generation code.

---

## Mandatory Pre-Response Checklist

Before sending the final response, verify each box:

```
[ ] Deliverable classified (document / chart / code / summary)
[ ] Matching Skill loaded if document or chart
[ ] File saved to /home/z/my-project/download/<name>.<ext>
[ ] ls -la /home/z/my-project/download/ confirms file exists, size > 0
[ ] send_message called with file path (IM mode only)
[ ] Response text mentions file name + next step
```

If any box is unchecked, the response is incomplete. Do not send.

---

## File Naming Conventions (for reliable delivery)

Good names (specific, dated, versioned):
- `classroom-tools-globals-fix-v1.md`
- `weekly-report-2026-08-17.pdf`
- `theme-palette-math-class.md`
- `patch-diff-2026-08-17.diff`

Bad names (ambiguous, collision-prone):
- `output.md`
- `report.pdf`
- `file.txt`
- `tmp.txt`

Always include enough context in the filename that the user can identify it in the panel without opening it.

---

## Multi-File Deliveries

When a task produces multiple files (e.g., a patch + an instructions doc + a screenshot):

1. Create a subdirectory: `/home/z/my-project/download/<task-name>/`
2. Save all files into it
3. In IM mode, call `send_message` once per file (or once with a list, depending on the tool's signature)
4. List all file names in the response text

Example:
```
/home/z/my-project/download/classroom-tools-theme-v1/
  ├── globals.css.patch
  ├── theme-tokens.md
  └── before-after-screenshot.png
```

---

## Fallback: The Minimum Viable Deliverable

If the primary deliverable fails (script crashes, font missing, network error, etc.), ALWAYS fall back to:

```
/home/z/my-project/download/summary.md
```

Containing:
- The full content of what you would have delivered
- A clear note at the top: "Primary deliverable failed; this MD contains the full content."
- The error message that caused the primary to fail

**An empty download panel is never acceptable.** A plain Markdown summary is always better than nothing.

---

## One-Paragraph Version (paste into system prompt)

> After every task, you MUST save at least one downloadable file to `/home/z/my-project/download/` using the `Write` tool or a persisted script. Verify the file exists with `ls -la /home/z/my-project/download/` before responding. In IM mode, call `send_message` with the absolute file path as the final tool call. The "All files in task" panel only populates when a real file exists on disk in that exact directory at the moment your response completes — chat text, code blocks, and files in other directories do NOT appear in the panel. If the primary deliverable fails, fall back to `summary.md` containing the full content. An empty panel is a critical failure.

---

## Quick Reference Card

```
DELIVERABLE PATH:   /home/z/my-project/download/<name>.<ext>
SCRIPT PATH:        /home/z/my-project/scripts/<name>.py
VERIFY COMMAND:     ls -la /home/z/my-project/download/
IM DELIVERY:        send_message(file_path="/home/z/my-project/download/<file>")
FALLBACK FILE:      /home/z/my-project/download/summary.md
FORBIDDEN PATHS:    /tmp, ~, project root, src/, ./output/, any non-/home/z/my-project/download/ path
```

---

**End of document. Paste this entire file into your other project's system prompt, CLAUDE.md, or agent instructions.**
