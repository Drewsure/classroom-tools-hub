"use client";

import { useCallback, useRef, useEffect, useState } from "react";
import { useSoundEnabled } from "@/components/timers/timer-launcher";

/**
 * Classroom Sound Pad Engine
 * Uses real high-quality audio files from Mixkit (free, royalty-free)
 * with Web Audio API synthesis as fallback if files fail to load.
 *
 * Features:
 * - Real audio files for rich sound quality
 * - Immediate STOP (pauses all active audio clones instantly)
 * - Working volume control (applies to all audio elements + future clones)
 * - Synthesis fallback if files fail to load
 */

export function useSoundPad() {
  const soundEnabled = useSoundEnabled();
  const audioMapRef = useRef<Map<string, HTMLAudioElement>>(new Map());
  const activeClonesRef = useRef<Set<HTMLAudioElement>>(new Set());
  const synthCtxRef = useRef<AudioContext | null>(null);
  const [volume, setVolume] = useState(0.7);
  const volumeRef = useRef(0.7);
  const [lastPlayed, setLastPlayed] = useState<string | null>(null);

  // Update volume on all audio elements AND the ref
  useEffect(() => {
    volumeRef.current = volume;
    // Update pre-loaded audio elements
    audioMapRef.current.forEach((audio) => {
      audio.volume = volume;
    });
    // Update currently playing clones
    activeClonesRef.current.forEach((clone) => {
      clone.volume = volume;
    });
  }, [volume]);

  // Pre-load all audio files on mount
  useEffect(() => {
    SOUND_FILES.forEach(({ id, file }) => {
      const audio = new Audio(`/sounds/${file}`);
      audio.preload = "auto";
      audio.volume = volumeRef.current;
      // Clean up clone when it finishes playing
      audio.addEventListener("ended", () => {
        // This won't fire for clones, but just in case
      });
      audioMapRef.current.set(id, audio);
    });

    return () => {
      // Stop all active clones
      activeClonesRef.current.forEach((clone) => {
        clone.pause();
        clone.src = "";
      });
      activeClonesRef.current.clear();
      // Clean up pre-loaded audio
      audioMapRef.current.forEach((audio) => {
        audio.pause();
        audio.src = "";
      });
      audioMapRef.current.clear();
    };
  }, []);

  // ===== Synthesis fallback =====
  const getSynthCtx = useCallback(() => {
    if (typeof window === "undefined") return null;
    if (!synthCtxRef.current) {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (!Ctor) return null;
      synthCtxRef.current = new Ctor();
    }
    return synthCtxRef.current;
  }, []);

  const synthTone = useCallback(
    (freq: number, duration: number, opts: { type?: OscillatorType; vol?: number; sweepTo?: number } = {}) => {
      if (!soundEnabled) return;
      const ctx = getSynthCtx();
      if (!ctx) return;
      if (ctx.state === "suspended") void ctx.resume();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = opts.type ?? "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      if (opts.sweepTo) osc.frequency.exponentialRampToValueAtTime(opts.sweepTo, ctx.currentTime + duration);
      const vol = (opts.vol ?? 0.3) * volumeRef.current;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(vol, ctx.currentTime + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    },
    [getSynthCtx, soundEnabled],
  );

  const synthNoise = useCallback(
    (duration: number, vol: number, filterFreq: number) => {
      if (!soundEnabled) return;
      const ctx = getSynthCtx();
      if (!ctx) return;
      const bufferSize = ctx.sampleRate * duration;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = filterFreq;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(vol * volumeRef.current, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      src.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      src.start();
    },
    [getSynthCtx, soundEnabled],
  );

  // Synthesis fallback sounds
  const synthFallback = useCallback(
    (id: string) => {
      switch (id) {
        case "cheer": synthNoise(1.2, 0.35, 2500); break;
        case "clap": for (let i = 0; i < 6; i++) setTimeout(() => synthNoise(0.08, 0.3, 1500), i * 100); break;
        case "ding": synthTone(1318.5, 0.6, { type: "sine", vol: 0.4 }); break;
        case "fanfare": [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => synthTone(f, 0.3, { type: "sawtooth", vol: 0.2 }), i * 150)); break;
        case "tada": [659, 784, 988, 1318].forEach((f, i) => setTimeout(() => synthTone(f, 0.1, { type: "triangle", vol: 0.2 }), i * 50)); break;
        case "wow": synthTone(300, 0.15, { type: "sawtooth", vol: 0.25, sweepTo: 500 }); setTimeout(() => synthTone(500, 0.2, { type: "sawtooth", vol: 0.25, sweepTo: 700 }), 150); break;
        case "boop": [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => synthTone(f, 0.3, { type: "sawtooth", vol: 0.2 }), i * 150)); break;
        case "buzzer": synthTone(150, 0.5, { type: "sawtooth", vol: 0.3 }); synthNoise(0.5, 0.15, 800); break;
        case "spring": synthTone(200, 0.3, { type: "sine", vol: 0.3, sweepTo: 800 }); break;
        case "drumroll": synthTone(60, 0.15, { type: "sine", vol: 0.4 }); setTimeout(() => synthTone(60, 0.15, { type: "sine", vol: 0.4 }), 300); break;
        case "laugh": [400, 350, 300].forEach((f, i) => setTimeout(() => synthTone(f, 0.12, { type: "sawtooth", vol: 0.25 }), i * 180)); break;
        case "cowbell": for (let i = 0; i < 12; i++) setTimeout(() => synthNoise(0.05, 0.2, 400), i * 60); break;
        case "gong": synthTone(80, 2, { type: "sine", vol: 0.4 }); synthNoise(0.5, 0.2, 2000); break;
        case "sparkle": [1046, 1318, 1568, 2093].forEach((f, i) => setTimeout(() => synthTone(f, 0.3, { type: "triangle", vol: 0.15 }), i * 60)); break;
        case "quack": [2000, 2400, 2000, 2200].forEach((f, i) => setTimeout(() => synthTone(f, 0.08, { type: "sine", vol: 0.15 }), i * 80)); break;
        case "monkey": synthTone(200, 0.1, { type: "sawtooth", vol: 0.3, sweepTo: 150 }); setTimeout(() => synthTone(180, 0.15, { type: "sawtooth", vol: 0.25, sweepTo: 120 }), 120); break;
        case "whoosh": synthTone(200, 0.4, { type: "sawtooth", vol: 0.2, sweepTo: 800 }); synthNoise(0.4, 0.15, 600); break;
        case "alarm": for (let i = 0; i < 3; i++) { setTimeout(() => synthTone(880, 0.12, { type: "square", vol: 0.2 }), i * 300); setTimeout(() => synthTone(988, 0.12, { type: "square", vol: 0.2 }), i * 300 + 150); } break;
      }
    },
    [synthTone, synthNoise],
  );

  // Main play function — plays real audio file, tracks clone for STOP
  const play = useCallback(
    (soundId: string) => {
      if (!soundEnabled) return;
      setLastPlayed(soundId);

      const audio = audioMapRef.current.get(soundId);
      if (audio) {
        // Clone the audio to allow rapid re-triggering AND tracking for STOP
        const clone = audio.cloneNode() as HTMLAudioElement;
        clone.volume = volumeRef.current;
        // Track this clone so STOP can kill it
        activeClonesRef.current.add(clone);
        // Clean up when it finishes playing
        clone.addEventListener("ended", () => {
          activeClonesRef.current.delete(clone);
          clone.src = "";
        });
        // Play with fallback
        clone.play().catch(() => {
          synthFallback(soundId);
          activeClonesRef.current.delete(clone);
        });
      } else {
        synthFallback(soundId);
      }
    },
    [soundEnabled, synthFallback],
  );

  // STOP ALL — immediately pauses and silences all active audio clones
  const stopAll = useCallback(() => {
    // Immediately pause and clear ALL active audio clones
    activeClonesRef.current.forEach((clone) => {
      clone.pause();
      clone.currentTime = 0;
      clone.src = "";
    });
    activeClonesRef.current.clear();

    // Also pause any pre-loaded audio elements (just in case)
    audioMapRef.current.forEach((audio) => {
      audio.pause();
      audio.currentTime = 0;
    });

    // Close and recreate the synth context to kill any ongoing synthesis
    if (synthCtxRef.current) {
      synthCtxRef.current.close().catch(() => {});
      synthCtxRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      if (synthCtxRef.current) void synthCtxRef.current.close();
    };
  }, []);

  return { play, stopAll, volume, setVolume, lastPlayed };
}

/* ============================================================
   SOUND DEFINITIONS — mapped to local audio files
   ============================================================ */
export interface SoundDef {
  id: string;
  label: string;
  emoji: string;
  color: string;
  category: "positive" | "funny" | "attention";
  key?: string;
  file: string;
}

export const SOUND_FILES: { id: string; file: string }[] = [
  { id: "cheer", file: "cheer.mp3" },       // cheer label → cheer sound
  { id: "clap", file: "clap.mp3" },          // clap label → clap sound
  { id: "ding", file: "ding.mp3" },
  { id: "fanfare", file: "wrong.mp3" },     // key 4 → Wrong sound
  { id: "tada", file: "tada.mp3" },
  { id: "wow", file: "wow.mp3" },
  { id: "boop", file: "drumroll.mp3" },     // boop → Drumroll (original drum roll)
  { id: "buzzer", file: "buzzer.mp3" },
  { id: "spring", file: "spring.mp3" },
  { id: "drumroll", file: "heartbeat.mp3" },
  { id: "laugh", file: "laugh.mp3" },
  { id: "cowbell", file: "gameshow.mp3" },
  { id: "gong", file: "timeup.mp3" },        // gong → Time Thinking
  { id: "sparkle", file: "sparkle.mp3" },
  { id: "quack", file: "chirping.mp3" },
  { id: "monkey", file: "dog.mp3" },
  { id: "whoosh", file: "whoosh.mp3" },
  { id: "alarm", file: "alarm.mp3" },
];

export const SOUNDS: SoundDef[] = [
  // Positive & Encouraging
  { id: "cheer", label: "Cheer", emoji: "🎉", color: "from-yellow-400 to-orange-500", category: "positive", key: "1", file: "cheer.mp3" },
  { id: "clap", label: "Clap", emoji: "👏", color: "from-pink-400 to-rose-500", category: "positive", key: "2", file: "clap.mp3" },
  { id: "tada", label: "Correct!", emoji: "✅", color: "from-green-400 to-emerald-500", category: "positive", key: "3", file: "tada.mp3" },
  { id: "laugh", label: "Laugh", emoji: "😂", color: "from-lime-400 to-green-500", category: "positive", key: "4", file: "laugh.mp3" },
  { id: "ding", label: "Great Job!", emoji: "🌟", color: "from-violet-400 to-purple-500", category: "positive", key: "5", file: "ding.mp3" },
  { id: "wow", label: "Wow!", emoji: "😮", color: "from-cyan-400 to-blue-500", category: "positive", key: "6", file: "wow.mp3" },

  // Game Show
  { id: "boop", label: "Game Show Start", emoji: "🥁", color: "from-amber-500 to-orange-600", category: "funny", key: "q", file: "drumroll.mp3" },
  { id: "buzzer", label: "Buzzer", emoji: "🚨", color: "from-red-500 to-rose-600", category: "funny", key: "w", file: "buzzer.mp3" },
  { id: "fanfare", label: "Wrong", emoji: "❌", color: "from-red-400 to-red-500", category: "funny", key: "e", file: "wrong.mp3" },
  { id: "drumroll", label: "Heart Beat", emoji: "❤️", color: "from-rose-500 to-red-600", category: "funny", key: "r", file: "heartbeat.mp3" },
  { id: "cowbell", label: "Game Show - Think!", emoji: "🎬", color: "from-indigo-500 to-purple-600", category: "funny", key: "t", file: "gameshow.mp3" },
  { id: "gong", label: "Time Thinking", emoji: "⏰", color: "from-red-500 to-orange-600", category: "funny", key: "y", file: "timeup.mp3" },

  // Attention & Fun
  { id: "sparkle", label: "Sparkle", emoji: "✨", color: "from-fuchsia-400 to-pink-500", category: "attention", key: "a", file: "sparkle.mp3" },
  { id: "spring", label: "Spring", emoji: "🤪", color: "from-teal-400 to-cyan-500", category: "attention", key: "s", file: "spring.mp3" },
  { id: "quack", label: "Chirping", emoji: "🐦", color: "from-sky-400 to-blue-500", category: "attention", key: "d", file: "chirping.mp3" },
  { id: "monkey", label: "Dog", emoji: "🐶", color: "from-amber-500 to-orange-600", category: "attention", key: "f", file: "dog.mp3" },
  { id: "whoosh", label: "Whoosh", emoji: "💨", color: "from-sky-400 to-indigo-500", category: "attention", key: "g", file: "whoosh.mp3" },
  { id: "alarm", label: "Alarm", emoji: "🚨", color: "from-red-500 to-orange-500", category: "attention", key: "h", file: "alarm.mp3" },
];
