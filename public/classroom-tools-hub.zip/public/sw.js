/* ============================================================
   Classroom Tools Hub — Service Worker
   ============================================================
   Strategies:
   - App shell (HTML, JS, CSS, _next/static) → stale-while-revalidate
   - Static media (sounds, icons, fonts)        → cache-first
   - Navigation (page loads)                     → network-first, fallback to cached shell

   The SW only activates in production builds.
   ============================================================ */

const VERSION = "v1.0.0";
const STATIC_CACHE = `cth-static-${VERSION}`;
const RUNTIME_CACHE = `cth-runtime-${VERSION}`;

// Assets to pre-cache on install (app shell + sounds + icons)
const PRECACHE_URLS = [
  "/",
  "/manifest.json",
  "/icons/icon-32.png",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/icons/maskable-192.png",
  "/icons/maskable-512.png",
  // Sounds — cached so the app works fully offline
  "/sounds/cheer.mp3",
  "/sounds/applause.mp3",
  "/sounds/laugh.mp3",
  "/sounds/boo.mp3",
  "/sounds/sad-trombone.mp3",
  "/sounds/tada.mp3",
  "/sounds/fanfare.mp3",
  "/sounds/drum-roll.mp3",
  "/sounds/crash.mp3",
  "/sounds/air-horn.mp3",
  "/sounds/ding.mp3",
  "/sounds/bell.mp3",
  "/sounds/buzzer.mp3",
  "/sounds/alarm.mp3",
  "/sounds/whistle.mp3",
  "/sounds/magic.mp3",
  "/sounds/great-job.mp3",
];

// Install — pre-cache the app shell
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) =>
      // Use addAll with individual failures tolerated (some sounds may 404)
      Promise.allSettled(PRECACHE_URLS.map((url) => cache.add(url))),
    ).then(() => self.skipWaiting()),
  );
});

// Activate — clean up old caches and take control
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== STATIC_CACHE && k !== RUNTIME_CACHE)
          .map((k) => caches.delete(k)),
      ),
    ).then(() => self.clients.claim()),
  );
});

// Helper — tell all open tabs an update is ready
const notifyClients = async () => {
  const clients = await self.clients.matchAll({ includeUncontrolled: true });
  clients.forEach((client) => client.postMessage({ type: "SW_UPDATED" }));
};

// Fetch — strategy routing
self.addEventListener("fetch", (event) => {
  const { request } = event;

  // Only handle GET — never intercept POST/PUT/etc.
  if (request.method !== "GET") return;

  const url = new URL(request.url);

  // Skip cross-origin requests (analytics, fonts CDN, etc.)
  if (url.origin !== self.location.origin) return;

  // Skip Next.js HMR / dev endpoints
  if (url.pathname.startsWith("/_next/webpack-hmr")) return;

  // --- Navigation requests (page loads): network-first, fall back to cached shell ---
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, copy)).catch(() => {});
          return response;
        })
        .catch(() => caches.match(request).then((r) => r || caches.match("/"))),
    );
    return;
  }

  // --- Sounds: cache-first (offline-critical) ---
  if (url.pathname.startsWith("/sounds/")) {
    event.respondWith(
      caches.match(request).then((cached) =>
        cached ||
        fetch(request).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(STATIC_CACHE).then((cache) => cache.put(request, copy)).catch(() => {});
          }
          return response;
        }).catch(() => cached),
      ),
    );
    return;
  }

  // --- Icons & manifest: cache-first ---
  if (url.pathname.startsWith("/icons/") || url.pathname === "/manifest.json") {
    event.respondWith(
      caches.match(request).then((cached) =>
        cached ||
        fetch(request).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(STATIC_CACHE).then((cache) => cache.put(request, copy)).catch(() => {});
          }
          return response;
        }).catch(() => cached),
      ),
    );
    return;
  }

  // --- App shell (JS, CSS, _next/static): stale-while-revalidate ---
  if (
    url.pathname.startsWith("/_next/static/") ||
    url.pathname.endsWith(".js") ||
    url.pathname.endsWith(".css") ||
    url.pathname.endsWith(".woff") ||
    url.pathname.endsWith(".woff2")
  ) {
    event.respondWith(
      caches.open(RUNTIME_CACHE).then((cache) =>
        cache.match(request).then((cached) => {
          const fetchPromise = fetch(request)
            .then((response) => {
              if (response.ok) cache.put(request, response.clone());
              return response;
            })
            .catch(() => cached);
          return cached || fetchPromise;
        }),
      ),
    );
    return;
  }

  // --- Default: try network, fall back to cache ---
  event.respondWith(
    fetch(request)
      .then((response) => {
        if (response.ok && response.type === "basic") {
          const copy = response.clone();
          caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, copy)).catch(() => {});
        }
        return response;
      })
      .catch(() => caches.match(request)),
  );
});

// Listen for messages from the page (e.g. "SKIP_WAITING" to apply updates immediately)
self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") {
    self.skipWaiting().then(notifyClients);
  }
});
